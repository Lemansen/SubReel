﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SubReel.Models.Chat
{
    public class ChatMessage
    {
        public string Nickname { get; set; } = "";
        public string Message { get; set; } = "";
        public string AvatarUrl => $"https://minotar.net/helm/{Nickname}/32.png";
    }
}
