﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;
using System.Windows;
using System.Windows.Media;

namespace SubReel.Models
{

    public class ReleasePopup
    {
        [JsonPropertyName("enabled")]
        public bool Enabled { get; set; }

        [JsonPropertyName("force")]
        public bool Force { get; set; }

        [JsonPropertyName("show_once")]
        public bool ShowOnce { get; set; }

        [JsonPropertyName("title")]
        public string Title { get; set; } = "";

        [JsonPropertyName("message")]
        public string Message { get; set; } = "";

        [JsonPropertyName("sub_message")]
        public string SubMessage { get; set; } = "";
    }
    public class MasterConfig
    {
        [JsonPropertyName("project_info")]
        public ProjectInfo? ProjectInfo { get; set; }

        // ИСПРАВЛЕНО: Привязываем к installer_config из JSON
        [JsonPropertyName("installer_config")]
        public UpdateModel? Installer { get; set; }

        [JsonPropertyName("launcher_status")]
        public LauncherStatus? Status { get; set; }

        [JsonPropertyName("news")]
        public List<NewsItem>? News { get; set; }
    }
    public class ProjectInfo
    {
        [JsonPropertyName("name")] public string Name { get; set; } = "";
    }

    public class UpdateModel
    {
        [JsonPropertyName("version")] public string Version { get; set; } = "";
        [JsonPropertyName("download_url")] public string DownloadUrl { get; set; } = "";
        [JsonPropertyName("changelog")] public List<string> Changelog { get; set; } = new();
    }

    public class LauncherStatus
    {
        [JsonPropertyName("online_count")] public int OnlineCount { get; set; } = 0;
        [JsonPropertyName("server_status")] public string ServerStatus { get; set; } = "";
        [JsonPropertyName("recent_changelog")] public List<string> RecentChangelog { get; set; } = new();
        [JsonPropertyName("release_popup")] public ReleasePopup? ReleasePopup { get; set; }
    }
    public class NewsItem
    {
        [JsonPropertyName("id")] public int Id { get; set; }
        [JsonPropertyName("category")] public string Category { get; set; } = "";
        [JsonPropertyName("title")] public string Title { get; set; } = "";
        [JsonPropertyName("date")] public string Date { get; set; } = "";
        [JsonPropertyName("description")] public string Description { get; set; } = "";
        [JsonPropertyName("accent_color")] public string AccentColor { get; set; } = "#FFCC00";
        [JsonPropertyName("changes")] public List<string> Changes { get; set; } = new();
        [JsonPropertyName("button_url")] public string ButtonUrl { get; set; } = "";
        [JsonPropertyName("button_text")] public string ButtonText { get; set; } = "";

        // Эти свойства ТЕПЕРЬ ВНУТРИ класса NewsItem
        [JsonIgnore]
        public Visibility ButtonVisibility => string.IsNullOrWhiteSpace(ButtonUrl) ? Visibility.Collapsed : Visibility.Visible;

        [JsonIgnore]

        public SolidColorBrush AccentBrush
        {
            get
            {
                try
                {
                    var converter = new BrushConverter();
                    var brushObj = converter.ConvertFrom(AccentColor ?? "#3374FF");
                    return (brushObj as SolidColorBrush) ?? Brushes.CornflowerBlue;
                }
                catch
                {
                    return Brushes.CornflowerBlue;
                }
            }
        }
    } // Конец класса NewsItem
}
