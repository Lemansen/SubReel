﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SubReel.Models
{
    public class LauncherSettings
    {
        public string Nickname { get; set; } = "Player";
        public double Ram { get; set; } = 4096;
        public bool IsLicensed { get; set; } = false;
        public string SelectedVersion { get; set; } = "1.21.1";
        public bool IsConsoleShow { get; set; } = false;
    }
    public enum JavaSourceType
    {
        Bundled,   // скачанная лаунчером
        System,    // из PATH
        Manual     // выбранная пользователем
    }
}
